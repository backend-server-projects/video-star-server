# Video Star
### Online video striming platform
## [Live Demo]('https://www.youtube.com/watch?v=m5gLN6etKtY') 

## `Features`
- user create
- user video striming
- video upload from home page